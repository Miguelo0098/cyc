function texto = descifro_permutacion(p, cifrado)
texto = cifro_permutacion(p,cifrado);